### PlatformOS blog module

### Installation

As a dependency Blog module is using https://github.com/appko/pos-utils so make sure you install it first.

### Troubleshooting

If you have problem with WYSIWYG editor, it might be missing assets as the one used are precompiled. Quick fix copy "wysiwyg.b90.js" to `marketplace_builder/assets/` and `trumbowyg-icons.svg` to `marketplace_builder/assets/images`. Soon to be fixed.


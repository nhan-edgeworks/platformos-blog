### PlatformOS module to create basic sign-up/log-in functionality
